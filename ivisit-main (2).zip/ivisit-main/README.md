# iVisit - Visitor Management System


## Requirements

-   PHP 8.0 or higher
-   MySQL or MariaDB
-   Apache (with `mod_rewrite` enabled)

## Installation

1.  **Database Setup**
    
    -   Create a database named `ivisit`.
    -   Import the `database.sql` file located in the root directory.
2.  **Configuration**
    
    -   Check `app/Config/config.php` if you need to change database credentials.
    -   Default settings:
        -   Host: `localhost`
        -   User: `root`
        -   Pass: (empty)
3.  **Running the App**
    
    -   Access the project via the `public` folder:
        
        ```
        http://localhost/ivisit/public
        ```
        

## IMPORTANT: First Run

The original database dump contained plaintext passwords. I've added a utility to secure them. Be sure to run this **once** before trying to log in:

**Run this URL:**  
`http://localhost/ivisit/public/setup/fix_passwords`

This will encrypt existing admin passwords so the login system works correctly.

## Project Structure

-   `app/` - Core application logic (Controllers, Models, Views).
-   `public/` - Publicly accessible files (index.php, CSS, JS).
-   `database.sql` - Enhanced database schema with optimizations.

## Features

-   **Visitor Registration:** Front-end form for guests to check in.
-   **Admin Dashboard:** Real-time stats and visitor logs.
-   **Feedback System:** Visitors can rate their experience.
-   **Search & Filter:** Admin can filter logs by date, status, or purpose.

## Login Credentials

After running the password fix script, you can use the existing accounts in the database (e.g., `admin@example.com`).
