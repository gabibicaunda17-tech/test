-- Add this to your database
CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed with some initial data
INSERT INTO departments (name, description) VALUES 
('Human Resources', 'Handles recruitment, benefits, and employee relations'),
('IT Support', 'Technical assistance and infrastructure'),
('Sales', 'Sales team and client communications'),
('Finance', 'Accounting and payroll'),
('Administration', 'General office management'),
('Legal', 'Legal compliance and contracts'),
('Operations', 'Daily business operations'),
('Customer Service', 'Handling customer inquiries');
