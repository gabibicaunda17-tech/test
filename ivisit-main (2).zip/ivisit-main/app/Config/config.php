<?php
// app/Config/config.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'ivisit');
define('DB_USER', 'root');
define('DB_PASS', '');

// Base URL (adjust if in subfolder)
define('BASE_URL', 'http://localhost/ivisit/public');

// Site Name
define('SITE_NAME', 'iVisit');

// App Root
define('APP_ROOT', dirname(dirname(__FILE__)));
