<?php
// app/Core/Controller.php

class Controller {
    public function model($model) {
        require_once '../app/Models/' . $model . '.php';
        return new $model();
    }

    public function view($view, $data = []) {
        // Extract data for view usage
        extract($data); 
        
        if (file_exists('../app/Views/' . $view . '.php')) {
            require_once '../app/Views/' . $view . '.php';
        } else {
            die("View does not exist: " . $view);
        }
    }

    public function redirect($url) {
        header('Location: ' . BASE_URL . '/' . $url);
        exit;
    }
}
