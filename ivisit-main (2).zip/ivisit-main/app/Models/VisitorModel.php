<?php
class VisitorModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function registerVisit($data) {
        $pdo = $this->db->getConnection();
        
        try {
            $pdo->beginTransaction();

            // 1. Insert Visitor
            $stmt = $pdo->prepare("INSERT INTO visitors (full_name, contact_number, email, organization) 
                                   VALUES (:full_name, :contact_number, :email, :organization)");
            $stmt->execute([
                ':full_name' => $data['full_name'],
                ':contact_number' => $data['contact_number'],
                ':email' => $data['email'],
                ':organization' => $data['organization']
            ]);
            $visitorId = $pdo->lastInsertId();

            // 2. Insert Visit
            $stmt = $pdo->prepare("INSERT INTO visits (visitor_id, person_to_visit, department, purpose, purpose_details, time_in, status) 
                                   VALUES (:visitor_id, :person_to_visit, :department, :purpose, :purpose_details, NOW(), 'IN')");
            $stmt->execute([
                ':visitor_id' => $visitorId,
                ':person_to_visit' => $data['person_to_visit'],
                ':department' => $data['department'],
                ':purpose' => $data['purpose'],
                ':purpose_details' => $data['purpose_details']
            ]);
            $visitId = $pdo->lastInsertId();

            $pdo->commit();
            return $visitId;
        } catch (Exception $e) {
            $pdo->rollBack();
            return false;
        }
    }

    public function submitFeedback($data) {
        $stmt = $this->db->getConnection()->prepare("
            INSERT INTO feedback (visit_id, rating, comment, suggestion, contact_email)
            VALUES (:visit_id, :rating, :comment, :suggestion, :contact_email)
        ");
        
        return $stmt->execute([
            ':visit_id'      => $data['visit_id'] ?: null,
            ':rating'        => $data['rating'],
            ':comment'       => $data['comment'],
            ':suggestion'    => $data['suggestion'],
            ':contact_email' => $data['contact_email']
        ]);
    }
}
