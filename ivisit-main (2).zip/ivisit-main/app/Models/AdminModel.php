<?php
// app/Models/AdminModel.php

class AdminModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findUserByEmail($email) {
        $stmt = $this->db->query("SELECT * FROM admins WHERE email = :email", [
            ':email' => $email
        ]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function login($email, $password) {
        $user = $this->findUserByEmail($email);

        if (!$user) return false;

        // Check if password needs rehash (if it's not a valid hash)
        // This is a temporary fix for the migration phase to handle plaintext passwords if necessary
        // Ideally we run a migration script, but here we can't easily do "try verify, if fail try plaintext".
        // Actually, we should just expect hashed passwords. I will provide a separate cleanup tool.
        
        if (password_verify($password, $user['password_hash'])) {
            return $user;
        }

        return false;
    }
    
    // Helper to update login timestamp
    public function updateLoginTimestamp($id) {
        $this->db->query("UPDATE admins SET last_login_at = NOW() WHERE id = :id", [':id' => $id]);
    }

    public function getDashboardStats() {
        return [
            'totalToday' => $this->db->query("SELECT COUNT(*) AS c FROM visits WHERE DATE(time_in) = CURDATE()")->fetch()['c'],
            'inOffice' => $this->db->query("SELECT COUNT(*) AS c FROM visits WHERE status = 'IN'")->fetch()['c'],
            'avgRating' => $this->db->query("SELECT ROUND(AVG(rating),1) AS r FROM feedback")->fetch()['r'] ?? 'N/A'
        ];
    }

    public function getTodaysVisits() {
        return $this->db->query("
            SELECT v.id, vs.full_name, v.time_in, v.time_out, v.status, v.purpose
            FROM visits v
            JOIN visitors vs ON v.visitor_id = vs.id
            WHERE DATE(v.time_in) = CURDATE()
            ORDER BY v.time_in DESC
            LIMIT 20
        ")->fetchAll();
    }

    public function markVisitorOut($visitId) {
        $stmt = $this->db->query("
            UPDATE visits 
            SET time_out = NOW(), status = 'OUT' 
            WHERE id = :id AND status = 'IN'
        ", [':id' => $visitId]);
        
        return $stmt->rowCount() > 0;
    }

    public function getDistinctPurposes() {
        return $this->db->query("SELECT DISTINCT purpose FROM visits WHERE purpose IS NOT NULL AND purpose != '' ORDER BY purpose")->fetchAll(PDO::FETCH_COLUMN);
    }

    public function searchVisits($filters, $limit = 20, $offset = 0) {
        $where = ["DATE(v.time_in) BETWEEN :date_from AND :date_to"];
        $params = [
            ':date_from' => $filters['date_from'],
            ':date_to' => $filters['date_to']
        ];

        if (!empty($filters['status'])) {
            $where[] = "v.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['purpose'])) {
            $where[] = "v.purpose = :purpose";
            $params[':purpose'] = $filters['purpose'];
        }

        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $where[] = "(vs.full_name LIKE :search1 OR vs.contact_number LIKE :search2 OR vs.email LIKE :search3 OR v.person_to_visit LIKE :search4 OR v.department LIKE :search5 OR vs.organization LIKE :search6)";
            $params[':search1'] = $search;
            $params[':search2'] = $search;
            $params[':search3'] = $search;
            $params[':search4'] = $search;
            $params[':search5'] = $search;
            $params[':search6'] = $search;
        }

        $sql = "
            SELECT v.id, v.time_in, v.time_out, v.status, v.purpose, v.purpose_details, 
                   v.person_to_visit, v.department,
                   vs.full_name, vs.contact_number, vs.email, vs.organization
            FROM visits v
            JOIN visitors vs ON v.visitor_id = vs.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY v.time_in DESC
            LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

        return $this->db->query($sql, $params)->fetchAll();
    }

    public function getVisitsCount($filters) {
        $where = ["DATE(v.time_in) BETWEEN :date_from AND :date_to"];
        $params = [
            ':date_from' => $filters['date_from'],
            ':date_to' => $filters['date_to']
        ];

        if (!empty($filters['status'])) {
            $where[] = "v.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['purpose'])) {
            $where[] = "v.purpose = :purpose";
            $params[':purpose'] = $filters['purpose'];
        }

        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $where[] = "(vs.full_name LIKE :search1 OR vs.contact_number LIKE :search2 OR vs.email LIKE :search3 OR v.person_to_visit LIKE :search4 OR v.department LIKE :search5 OR vs.organization LIKE :search6)";
            $params[':search1'] = $search;
            $params[':search2'] = $search;
            $params[':search3'] = $search;
            $params[':search4'] = $search;
            $params[':search5'] = $search;
            $params[':search6'] = $search;
        }

        $sql = "
            SELECT COUNT(*) as total
            FROM visits v
            JOIN visitors vs ON v.visitor_id = vs.id
            WHERE " . implode(' AND ', $where);

        $result = $this->db->query($sql, $params)->fetch();
        return $result ? $result['total'] : 0;
    }


    public function getFeedback($filters, $limit = 10, $offset = 0) {
        $where = ["DATE(f.submitted_at) BETWEEN :date_from AND :date_to"];
        $params = [
            ':date_from' => $filters['date_from'],
            ':date_to' => $filters['date_to']
        ];

        if (!empty($filters['rating'])) {
            $where[] = "f.rating = :rating";
            $params[':rating'] = (int)$filters['rating'];
        }

        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $where[] = "(vs.full_name LIKE :search1 OR f.comment LIKE :search2 OR f.suggestion LIKE :search3)";
            $params[':search1'] = $search;
            $params[':search2'] = $search;
            $params[':search3'] = $search;
        }

        $sql = "
            SELECT f.id, f.rating, f.comment, f.suggestion, f.contact_email, f.submitted_at,
                   vs.full_name AS visitor_name
            FROM feedback f
            LEFT JOIN visits v ON f.visit_id = v.id
            LEFT JOIN visitors vs ON v.visitor_id = vs.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY f.submitted_at DESC
            LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

        return $this->db->query($sql, $params)->fetchAll();
    }

    public function getFeedbackCount($filters) {
        $where = ["DATE(f.submitted_at) BETWEEN :date_from AND :date_to"];
        $params = [
            ':date_from' => $filters['date_from'],
            ':date_to' => $filters['date_to']
        ];

        if (!empty($filters['rating'])) {
            $where[] = "f.rating = :rating";
            $params[':rating'] = (int)$filters['rating'];
        }

        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $where[] = "(vs.full_name LIKE :search1 OR f.comment LIKE :search2 OR f.suggestion LIKE :search3)";
            $params[':search1'] = $search;
            $params[':search2'] = $search;
            $params[':search3'] = $search;
        }

        $sql = "
            SELECT COUNT(*) as total
            FROM feedback f
            LEFT JOIN visits v ON f.visit_id = v.id
            LEFT JOIN visitors vs ON v.visitor_id = vs.id
            WHERE " . implode(' AND ', $where);

        $result = $this->db->query($sql, $params)->fetch();
        return $result ? $result['total'] : 0;
    }

    public function getWeeklyVisitStats() {
        // Last 7 days, including today
        $data = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $sql = "SELECT COUNT(*) as count FROM visits WHERE DATE(time_in) = :date";
            // Note: In strict loop this is N+1 queries but for 7 days it's fine and simple.
            // Or better: single query.
            // Let's do single query properly.
            $data[$date] = 0;
        }

        $sql = "SELECT DATE(time_in) as visit_date, COUNT(*) as count 
                FROM visits 
                WHERE time_in >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
                GROUP BY DATE(time_in)";
        
        $rows = $this->db->query($sql)->fetchAll();
        foreach ($rows as $row) {
            $data[$row['visit_date']] = $row['count'];
        }

        return $data;
    }

    public function getTopDepartments($limit = 5) {
        $sql = "SELECT department, COUNT(*) as count 
                FROM visits 
                WHERE department IS NOT NULL AND department != '' 
                GROUP BY department 
                ORDER BY count DESC 
                LIMIT " . (int)$limit;
        return $this->db->query($sql)->fetchAll();
    }

    public function getRecentFeedback($limit = 3) {
        $sql = "SELECT f.rating, f.comment, f.submitted_at, vs.full_name
                FROM feedback f
                LEFT JOIN visits v ON f.visit_id = v.id
                LEFT JOIN visitors vs ON v.visitor_id = vs.id
                ORDER BY f.submitted_at DESC
                LIMIT " . (int)$limit;
        return $this->db->query($sql)->fetchAll();
    }
}
