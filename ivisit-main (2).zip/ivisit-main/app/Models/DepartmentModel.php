<?php
class DepartmentModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAllDepartments() {
        return $this->db->query("SELECT * FROM departments ORDER BY name ASC")->fetchAll();
    }

    public function getDepartmentById($id) {
        $stmt = $this->db->query("SELECT * FROM departments WHERE id = :id", [':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function addDepartment($data) {
        try {
            $stmt = $this->db->query("INSERT INTO departments (name, description) VALUES (:name, :description)", [
                ':name' => $data['name'],
                ':description' => $data['description']
            ]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function updateDepartment($id, $data) {
        try {
            $stmt = $this->db->query("UPDATE departments SET name = :name, description = :description WHERE id = :id", [
                ':name' => $data['name'],
                ':description' => $data['description'],
                ':id' => $id
            ]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function deleteDepartment($id) {
        try {
            // Optional: Check if used in visits first? 
            // For now, simple delete. In real app, might want to soft delete or check FK.
            $stmt = $this->db->query("DELETE FROM departments WHERE id = :id", [':id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
}