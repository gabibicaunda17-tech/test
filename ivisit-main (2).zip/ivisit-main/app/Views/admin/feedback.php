<?php $title = "Visitor Feedback"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<!-- Navbar -->
<nav class="navbar">
    <div class="container">
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="brand"><?php echo SITE_NAME; ?> Admin</a>
        <div class="nav-links">
            <a href="<?php echo BASE_URL; ?>/admin/dashboard">Overview</a>
            <a href="<?php echo BASE_URL; ?>/admin/visits">All Visits</a>
            <a href="<?php echo BASE_URL; ?>/department/index">Departments</a>
            <a href="<?php echo BASE_URL; ?>/admin/feedback" class="active">Feedback</a>
            <a href="<?php echo BASE_URL; ?>/admin/logout" class="text-muted" style="color: var(--danger-color);">Logout</a>
        </div>
    </div>
</nav>

<div class="container fade-in">
    <div class="d-flex justify-between align-center mb-4">
        <h1>User Feedback</h1>
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="btn btn-secondary btn-sm">&larr; Back to Dashboard</a>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4" style="padding: 1.5rem; background: #fff; margin-bottom: 2rem;">
        <form method="GET" action="<?php echo BASE_URL; ?>/admin/feedback" style="display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Search</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($filters['search'] ?? ''); ?>" placeholder="Visitor name or comment..." style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div style="flex: 0 0 150px;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Rating</label>
                <select name="rating" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All Ratings</option>
                    <option value="5" <?php echo ($filters['rating'] == '5') ? 'selected' : ''; ?>>5 Stars</option>
                    <option value="4" <?php echo ($filters['rating'] == '4') ? 'selected' : ''; ?>>4 Stars</option>
                    <option value="3" <?php echo ($filters['rating'] == '3') ? 'selected' : ''; ?>>3 Stars</option>
                    <option value="2" <?php echo ($filters['rating'] == '2') ? 'selected' : ''; ?>>2 Stars</option>
                    <option value="1" <?php echo ($filters['rating'] == '1') ? 'selected' : ''; ?>>1 Star</option>
                </select>
            </div>

            <div style="flex: 0 0 150px;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">From Date</label>
                <input type="date" name="date_from" value="<?php echo htmlspecialchars($filters['date_from']); ?>" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>

            <div style="flex: 0 0 150px;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">To Date</label>
                <input type="date" name="date_to" value="<?php echo htmlspecialchars($filters['date_to']); ?>" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>

            <button type="submit" class="btn btn-primary" style="height: 38px;">Filter</button>
            <a href="<?php echo BASE_URL; ?>/admin/feedback" class="btn btn-secondary" style="height: 38px; line-height: 16px; background: #eee; color: #333;">Reset</a>
        </form>
    </div>

    <!-- Feedback Summary -->
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Average Rating</h3>
            <?php 
                // Note: These stats are currently based on the PAGE results. 
                // Ideally, this should be a separate query for global stats, but for now we keep it simple or remove if misleading.
                // Converting to use all available feedbacks passed from controller could be heavy if we paginate. 
                // Let's assume stats should reflect the filtered set but maybe across all pages? 
                // For now, let's keep it based on visible items or remove. 
                // Better approach: Since we have pagination, calculating average on partial data is wrong.
                // I will hide these stats for now as requested "put also pagination and advance filters", 
                // usually stats are secondary or need a dedicated query.
                // However, I will leave them but add a note or just show total items found.
            ?>
            <div class="value" style="font-size: 1.5rem; color: #555;">
                <?php echo $pagination['total_items']; ?> <span style="font-size: 1rem; color: #888;">Records Found</span>
            </div>
        </div>
    </div>

    <!-- Feedback List -->
    <div class="card">
        <div class="table-responsive">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #eee; text-align: left;">
                        <th style="padding: 1rem; width: 20%;">Visitor</th>
                        <th style="padding: 1rem; width: 15%; text-align: center;">Rating</th>
                        <th style="padding: 1rem; width: 50%;">Comments</th>
                        <th style="padding: 1rem; width: 15%; text-align: right;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($feedbacks)): ?>
                        <tr><td colspan="4" class="text-center text-muted" style="padding: 2rem;">No feedback found matching your criteria.</td></tr>
                    <?php else: ?>
                        <?php foreach ($feedbacks as $item): ?>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 1rem; font-weight: 500; vertical-align: top;">
                                <?php echo htmlspecialchars($item['visitor_name'] ?? 'Guest'); ?>
                                <div style="font-size: 0.8rem; color: #888; margin-top: 4px;"><?php echo htmlspecialchars($item['contact_email'] ?? ''); ?></div>
                            </td>
                            <td style="padding: 1rem; text-align: center; vertical-align: top;">
                                <div class="badge badge-star" style="display: inline-block; white-space: nowrap; color: #ffc107;">
                                    <?php echo str_repeat('★', $item['rating']); ?><?php echo str_repeat('<span style="color: #ddd;">★</span>', 5 - $item['rating']); ?>
                                </div>
                                <div class="text-muted" style="font-size: 0.8rem; margin-top: 4px;">(<?php echo $item['rating']; ?>/5)</div>
                            </td>
                            <td style="padding: 1rem; vertical-align: top;">
                                <?php if (!empty($item['comment'])): ?>
                                    <p style="margin: 0; white-space: pre-wrap;"><?php echo htmlspecialchars($item['comment']); ?></p>
                                <?php else: ?>
                                    <span class="text-muted" style="font-style: italic;">No comment provided</span>
                                <?php endif; ?>
                                
                                <?php if (!empty($item['suggestion'])): ?>
                                    <div style="background: #f9f9f9; padding: 0.5rem; margin-top: 0.5rem; border-left: 3px solid var(--info-color); border-radius: 2px;">
                                        <small class="text-muted d-block" style="font-weight: 600;">Suggestion:</small>
                                        <small><?php echo htmlspecialchars($item['suggestion']); ?></small>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 1rem; text-align: right; vertical-align: top;">
                                <div style="font-weight: 500;"><?php echo date('M j, Y', strtotime($item['submitted_at'])); ?></div>
                                <small class="text-muted"><?php echo date('g:i A', strtotime($item['submitted_at'])); ?></small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($pagination['total_pages'] > 1): ?>
        <div style="padding: 1rem; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #eee;">
            <div class="text-muted">
                Showing <?php echo (($pagination['current_page'] - 1) * 10) + 1; ?> to <?php echo min($pagination['current_page'] * 10, $pagination['total_items']); ?> of <?php echo $pagination['total_items']; ?> results
            </div>
            <div class="pagination" style="display: flex; gap: 0.5rem;">
                <?php 
                    $queryParams = $_GET;
                    unset($queryParams['page']);
                    $queryString = http_build_query($queryParams);
                    $baseUrl = BASE_URL . '/admin/feedback?' . $queryString;
                ?>

                <!-- Previous -->
                <?php if ($pagination['current_page'] > 1): ?>
                    <a href="<?php echo $baseUrl . '&page=' . ($pagination['current_page'] - 1); ?>" class="btn btn-secondary btn-sm">Previous</a>
                <?php else: ?>
                    <button class="btn btn-secondary btn-sm" disabled style="opacity: 0.5; cursor: not-allowed;">Previous</button>
                <?php endif; ?>

                <!-- Page Numbers (Simple) -->
                <?php for($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <a href="<?php echo $baseUrl . '&page=' . $i; ?>" class="btn btn-sm <?php echo ($i == $pagination['current_page']) ? 'btn-primary' : 'btn-secondary'; ?>" 
                       style="<?php echo ($i == $pagination['current_page']) ? 'pointer-events: none;' : 'background: #fff; color: #333; border: 1px solid #ddd;'; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>

                <!-- Next -->
                <?php if ($pagination['current_page'] < $pagination['total_pages']): ?>
                    <a href="<?php echo $baseUrl . '&page=' . ($pagination['current_page'] + 1); ?>" class="btn btn-secondary btn-sm">Next</a>
                <?php else: ?>
                    <button class="btn btn-secondary btn-sm" disabled style="opacity: 0.5; cursor: not-allowed;">Next</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
