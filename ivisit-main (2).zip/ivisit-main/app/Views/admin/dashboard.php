<?php $title = "Dashboard"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<!-- Navbar -->
<nav class="navbar">
    <div class="container">
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="brand"><?php echo SITE_NAME; ?> Admin</a>
        <div class="nav-links">
            <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="active">Overview</a>
            <a href="<?php echo BASE_URL; ?>/admin/visits">All Visits</a>
            <a href="<?php echo BASE_URL; ?>/department/index">Departments</a>
            <a href="<?php echo BASE_URL; ?>/admin/feedback">Feedback</a>
            <a href="<?php echo BASE_URL; ?>/admin/logout" class="text-muted" style="color: var(--danger-color);">Logout</a>
        </div>
    </div>
</nav>

<div class="container fade-in">
    <div class="dashboard-header mb-4">
        <h1>Dashboard Overview</h1>
        <div class="badge badge-out"><?php echo date('l, F j, Y'); ?></div>
    </div>

    <style>
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .stat-card h3 { font-size: 0.9rem; color: #7f8c8d; margin-bottom: 5px; }
        .stat-card .value { font-size: 1.8rem; font-weight: 700; color: #2c3e50; }

        @media (max-width: 992px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .dashboard-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }
            .dashboard-header h1 {
                font-size: 1.75rem;
                margin-bottom: 0;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total Visitors Today</h3>
            <div class="value"><?php echo $stats['totalToday'] ?? 0; ?></div>
        </div>
        <div class="stat-card">
            <h3>Currently In Office</h3>
            <div class="value" style="color: var(--success-color);"><?php echo $stats['inOffice'] ?? 0; ?></div>
        </div>
        <div class="stat-card">
            <h3>Avg. Feedback Rating</h3>
            <div class="value" style="color: var(--info-color);"><?php echo $stats['avgRating'] ?? 'N/A'; ?> <span style="font-size: 1rem;">★</span></div>
        </div>
    </div>

    <div class="dashboard-grid">
        <!-- Left Column: Chart -->
        <div class="card" style="margin-bottom: 0; min-height: 400px; display: flex; flex-direction: column;">
            <div class="card-header">
                <h3>Weekly Traffic</h3>
            </div>
            <div style="position: relative; flex: 1; min-height: 0;">
                <canvas id="weeklyVisitorsChart"></canvas>
            </div>
        </div>

        <!-- Right Column: Top Depts & Feedback -->
        <div class="right-col" style="display: flex; flex-direction: column; gap: 20px;">
            <!-- Top Departments -->
            <div class="card" style="margin-bottom: 0;">
                <div class="card-header">
                    <h3>Top Departments</h3>
                </div>
                <ul class="list-group" style="list-style: none; padding: 0;">
                    <?php if (empty($topDepartments)): ?>
                        <li class="text-muted">No data yet.</li>
                    <?php else: ?>
                        <?php foreach ($topDepartments as $dept): ?>
                        <li style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee;">
                            <span><?php echo htmlspecialchars($dept['department']); ?></span>
                            <span class="badge badge-primary" style="background: var(--primary-color); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8em;"><?php echo $dept['count']; ?></span>
                        </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Recent Feedback -->
            <div class="card" style="margin-bottom: 0;">
                <div class="card-header">
                    <h3>Recent Feedback</h3>
                    <a href="<?php echo BASE_URL; ?>/admin/feedback" style="font-size: 0.8rem;">View All</a>
                </div>
                <div>
                    <?php if (empty($recentFeedback)): ?>
                        <p class="text-muted">No feedback yet.</p>
                    <?php else: ?>
                        <?php foreach ($recentFeedback as $fb): ?>
                        <div style="margin-bottom: 15px; border-bottom: 1px solid #f0f0f0; padding-bottom: 10px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                <strong style="font-size: 0.9em;"><?php echo htmlspecialchars($fb['full_name'] ?? 'Anonymous'); ?></strong>
                                <span style="color: #f39c12; font-size: 0.9em;">
                                    <?php for($i=0; $i<$fb['rating']; $i++) echo '★'; ?>
                                </span>
                            </div>
                            <p style="font-size: 0.85em; color: #666; margin: 0; font-style: italic;">
                                "<?php echo htmlspecialchars(substr($fb['comment'], 0, 50)) . (strlen($fb['comment']) > 50 ? '...' : ''); ?>"
                            </p>
                            <small class="text-muted" style="font-size: 0.75em;"><?php echo date('M j, h:i A', strtotime($fb['submitted_at'])); ?></small>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card">
        <div class="card-header">
            <h3>Today's Check-Ins</h3>
            <a href="<?php echo BASE_URL; ?>/admin/visits" class="btn btn-sm btn-secondary">View All &rarr;</a>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Guest Name</th>
                        <th>Visit Purpose</th>
                        <th>Check-In Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($visits)): ?>
                        <tr><td colspan="5" class="text-center text-muted">No visits recorded today.</td></tr>
                    <?php else: ?>
                        <?php foreach (array_slice($visits, 0, 5) as $visit): ?>
                        <tr>
                            <td style="font-weight: 500;"><?php echo htmlspecialchars($visit['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($visit['purpose']); ?></td>
                            <td><?php echo date('h:i A', strtotime($visit['time_in'])); ?></td>
                            <td>
                                <?php if ($visit['status'] == 'OUT'): ?>
                                    <span class="badge badge-out">Checked Out</span>
                                <?php else: ?>
                                    <span class="badge badge-in">Active</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($visit['status'] == 'IN'): ?>
                                    <form action="<?php echo BASE_URL; ?>/admin/mark_timeout" method="POST" style="display:inline;">
                                        <input type="hidden" name="visit_id" value="<?php echo $visit['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Time Out</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted"><?php echo date('h:i A', strtotime($visit['time_out'])); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('weeklyVisitorsChart').getContext('2d');
    const weeklyData = <?php echo json_encode($weeklyStats); ?>;
    
    // Sort keys
    const labels = Object.keys(weeklyData).sort();
    const data = labels.map(date => weeklyData[date]);

    // Format dates
    const formattedLabels = labels.map(dateStr => {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: formattedLabels,
            datasets: [{
                label: 'Visitors',
                data: data,
                backgroundColor: 'rgba(52, 152, 219, 0.7)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 1,
                borderRadius: 4,
                hoverBackgroundColor: 'rgba(52, 152, 219, 1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    },
                    grid: {
                        display: true,
                        drawBorder: false,
                        color: '#f0f0f0'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#2c3e50',
                    titleFont: { family: 'Inter', size: 13 },
                    bodyFont: { family: 'Inter', size: 13 },
                    padding: 10,
                    cornerRadius: 4,
                    displayColors: false
                }
            }
        }
    });
});
</script>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
