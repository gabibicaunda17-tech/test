<?php $title = "Admin Login"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<div class="login-page">
    <div class="login-wrapper">
        <div class="card login-card">
            <div class="text-center mb-4">
                <h2 style="color: var(--primary-color);">Admin Access</h2>
                <p class="text-muted">Secure Login Portal</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger text-center"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/admin/login" method="POST">
                <div class="form-group">
                    <label for="email">Username / Email</label>
                    <input type="text" id="email" name="email" required autofocus>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 2rem;">Sign In</button>
            </form>
            
            <div class="text-center mt-3">
                <a href="<?php echo BASE_URL; ?>/" class="text-muted" style="font-size: 0.9rem;">&larr; Return to Home</a>
            </div>
        </div>
    </div>
</div>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
