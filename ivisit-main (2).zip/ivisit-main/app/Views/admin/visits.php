<?php $title = "All Visits"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<!-- Navbar -->
<nav class="navbar">
    <div class="container">
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="brand"><?php echo SITE_NAME; ?> Admin</a>
        <div class="nav-links">
            <a href="<?php echo BASE_URL; ?>/admin/dashboard">Overview</a>
            <a href="<?php echo BASE_URL; ?>/admin/visits" class="active">All Visits</a>
            <a href="<?php echo BASE_URL; ?>/department/index">Departments</a>
            <a href="<?php echo BASE_URL; ?>/admin/feedback">Feedback</a>
            <a href="<?php echo BASE_URL; ?>/admin/logout" class="text-muted" style="color: var(--danger-color);">Logout</a>
        </div>
    </div>
</nav>

<div class="container fade-in">
    <div class="d-flex justify-between align-center mb-4">
        <h1>Visit Log</h1>
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="btn btn-secondary btn-sm">&larr; Back to Dashboard</a>
    </div>

    <!-- Filters -->
    <div class="card mb-4" style="padding: 1.5rem; background: #fff; margin-bottom: 2rem;">
        <form action="" method="GET" class="filters-form">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px;">
                <div>
                    <label for="search">Search</label>
                    <input type="text" name="search" id="search" placeholder="Name, email, Dept..." value="<?php echo htmlspecialchars($filters['search'] ?? ''); ?>">
                </div>
                <div>
                    <label for="date_from">From Date</label>
                    <input type="date" name="date_from" id="date_from" value="<?php echo htmlspecialchars($filters['date_from'] ?? ''); ?>">
                </div>
                <div>
                    <label for="date_to">To Date</label>
                    <input type="date" name="date_to" id="date_to" value="<?php echo htmlspecialchars($filters['date_to'] ?? ''); ?>">
                </div>
                <div>
                    <label for="status">Status</label>
                    <select name="status" id="status">
                        <option value="">All Statuses</option>
                        <option value="IN" <?php echo ($filters['status'] ?? '') == 'IN' ? 'selected' : ''; ?>>Active (In)</option>
                        <option value="OUT" <?php echo ($filters['status'] ?? '') == 'OUT' ? 'selected' : ''; ?>>Completed (Out)</option>
                    </select>
                </div>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary">Filter Records</button>
                    <a href="<?php echo BASE_URL; ?>/admin/visits" class="btn btn-secondary" style="background: #e0e0e0; color: #333;">Reset</a>
                </div>
                
                <button type="submit" name="export" value="csv" class="btn btn-outline-primary" style="display: flex; align-items: center; gap: 8px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                    Export CSV
                </button>
            </div>
        </form>
    </div>

    <!-- Visits Table -->
    <div class="card">
        <div class="table-responsive">
            <table id="visitsTable">
                <thead>
                    <tr>
                        <th>Visitor Name</th>
                        <th>Host / Department</th>
                        <th>Purpose</th>
                        <th>Time In</th>
                        <th>Time Out</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($visits)): ?>
                        <tr><td colspan="7" class="text-center text-muted">No visits found matching criteria.</td></tr>
                    <?php else: ?>
                        <?php foreach ($visits as $visit): ?>
                        <tr>
                            <td>
                                <div style="font-weight: 500;"><?php echo htmlspecialchars($visit['full_name']); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($visit['organization'] ?? 'Private'); ?></small>
                            </td>
                            <td>
                                <div><?php echo htmlspecialchars($visit['person_to_visit']); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($visit['department']); ?></small>
                            </td>
                            <td>
                                <div><?php echo htmlspecialchars($visit['purpose']); ?></div>
                            </td>
                            <td><?php echo date('M j, h:i A', strtotime($visit['time_in'])); ?></td>
                            <td>
                                <?php echo $visit['time_out'] ? date('M j, h:i A', strtotime($visit['time_out'])) : '-'; ?>
                            </td>
                            <td>
                                <?php if ($visit['status'] == 'IN'): ?>
                                    <span class="badge badge-in">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-out">Complete</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($visit['status'] == 'IN'): ?>
                                    <form action="<?php echo BASE_URL; ?>/admin/mark_timeout" method="POST">
                                        <input type="hidden" name="visit_id" value="<?php echo $visit['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Time Out</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if (isset($totalPages) && $totalPages > 1): ?>
        <div class="pagination" style="display: flex; justify-content: center; gap: 5px; margin-top: 20px;">
            <?php 
            $queryParams = $_GET;
            unset($queryParams['page']);
            $queryString = http_build_query($queryParams);
            ?>
            
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&<?php echo $queryString; ?>" 
                   class="btn btn-sm <?php echo ($i == $currentPage) ? 'btn-primary' : 'btn-secondary'; ?>"
                   style="<?php echo ($i != $currentPage) ? 'background: #f0f0f0; color: #333;' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
