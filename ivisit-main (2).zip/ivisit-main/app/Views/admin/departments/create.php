<?php $title = "Add Department"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<div class="container fade-in">
    <h3>Add Department</h3>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-group">
            <label for="name">Department Name</label>
            <input type="text" name="name" id="name" required class="form-control">
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Save Department</button>
        <a href="<?php echo BASE_URL; ?>/department/index" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>