<?php $title = "Edit Department"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<div class="container fade-in">
    <h3>Edit Department</h3>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($department['id']); ?>">
        
        <div class="form-group">
            <label for="name">Department Name</label>
            <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($department['name']); ?>" required class="form-control">
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control"><?php echo htmlspecialchars($department['description']); ?></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Update Department</button>
        <a href="<?php echo BASE_URL; ?>/department/index" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>