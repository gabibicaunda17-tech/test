<?php require APP_ROOT . '/Views/layouts/header.php'; ?>

<!-- Navbar -->
<nav class="navbar">
    <div class="container">
        <a href="<?php echo BASE_URL; ?>/admin/dashboard" class="brand"><?php echo SITE_NAME; ?> Admin</a>
        <div class="nav-links">
            <a href="<?php echo BASE_URL; ?>/admin/dashboard">Overview</a>
            <a href="<?php echo BASE_URL; ?>/admin/visits">All Visits</a>
            <a href="<?php echo BASE_URL; ?>/department/index">Departments</a>
            <a href="<?php echo BASE_URL; ?>/admin/feedback">Feedback</a>
            <a href="<?php echo BASE_URL; ?>/admin/logout" class="text-muted" style="color: var(--danger-color);">Logout</a>
        </div>
    </div>
</nav>

<div class="container fade-in">
    <div class="d-flex justify-between align-center mb-4">
        <h1>Departments</h1>
        <a href="<?php echo BASE_URL; ?>/department/add" class="btn btn-primary btn-sm">+ Add New Department</a>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Department Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($departments)): ?>
                        <tr><td colspan="3" class="text-center text-muted">No departments found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($departments as $department): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($department['name']); ?></td>
                                <td><?php echo htmlspecialchars($department['description']); ?></td>
                                <td>
                                    <div class="d-flex" style="gap: 5px;">
                                        <a href="<?php echo BASE_URL; ?>/department/edit/<?php echo $department['id']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                                        <form action="<?php echo BASE_URL; ?>/department/delete/<?php echo $department['id']; ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this department?');">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>