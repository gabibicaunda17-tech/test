<?php $title = "Visitor Registration"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<div class="row align-center justify-center fade-in" style="min-height: 100vh; padding: 2rem 0;">
    <div class="container container-sm">
        <div class="card">
            <div class="text-center mb-4">
                <h1 style="color: var(--primary-color);">Visitor Registration</h1>
                <p class="text-muted">Please fill in your details to check in.</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/visitor/register" method="POST">
                
                <!-- Visitor details -->
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" required placeholder="John Doe">
                </div>

                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" id="contact_number" name="contact_number" required placeholder="+1 234 567 890">
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required placeholder="john@example.com">
                </div>

                <div class="form-group">
                    <label for="organization">Organization / Company (Optional)</label>
                    <input type="text" id="organization" name="organization" placeholder="Company Name">
                </div>

                <!-- Visit details -->
                <hr style="margin: 2rem 0; border: 0; border-top: 1px solid #eee;">

                <div class="form-group">
                    <label for="person_to_visit">Person to Visit</label>
                    <input type="text" id="person_to_visit" name="person_to_visit" required placeholder="Name of staff">
                </div>

                <div class="form-group">
                    <label for="department">Department</label>
                    <select id="department" name="department" required>
                        <option value="">Select Department...</option>
                        <?php if(!empty($departments)): ?>
                            <?php foreach($departments as $dept): ?>
                                <option value="<?php echo htmlspecialchars($dept['name']); ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <!-- Fallback if database is empty -->
                            <option value="HR">Human Resources</option>
                            <option value="IT">IT Support</option>
                            <option value="Sales">Sales & Marketing</option>
                            <option value="Finance">Finance</option>
                            <option value="Admin">Administration</option>
                            <option value="Legal">Legal</option>
                            <option value="Other">Other</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="purpose">Purpose of Visit</label>
                    <select id="purpose" name="purpose" required>
                        <option value="">Select Purpose...</option>
                        <option value="Meeting">Meeting</option>
                        <option value="Interview">Interview</option>
                        <option value="Delivery">Delivery</option>
                        <option value="Personal">Personal</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="purpose_details">Additional Details (Optional)</label>
                    <textarea id="purpose_details" name="purpose_details" rows="2" placeholder="Start time, etc."></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 2rem;">Check In</button>
            </form>
            
            <div class="text-center mt-3">
                <a href="<?php echo BASE_URL; ?>/" class="text-muted" style="font-size: 0.9rem;">&larr; Return to Home</a>
            </div>
        </div>
    </div>
</div>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
