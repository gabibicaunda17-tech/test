<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="app-container">

        <!-- Kiosk Navbar -->
        <nav class="landing-navbar">
            <a href="<?php echo BASE_URL; ?>/" class="brand">
                <span class="brand-dot"></span>
                <?php echo SITE_NAME; ?>
            </a>
            <a href="<?php echo BASE_URL; ?>/admin/login" class="btn btn-sm btn-outline-primary" style="font-weight: 600; padding: 8px 16px;">Staff Login</a>
        </nav>

        <!-- Kiosk Wrapper -->
        <div class="hero-wrapper">
            <div class="kiosk-card">
                <div class="kiosk-content">
                    <h1 class="hero-title">Welcome to Our Office.</h1>
                    <p class="hero-lead">Please register below to notify your host of your arrival.</p>
                    
                    <a href="<?php echo BASE_URL; ?>/visitor/register" class="action-btn action-btn-primary">
                        <span class="action-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        </span>
                        <span class="action-text">I'm here for a visit</span>
                        <span class="action-arrow">&rarr;</span>
                    </a>

                    <a href="<?php echo BASE_URL; ?>/visitor/feedback" class="action-btn">
                        <span class="action-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                        </span>
                        <span class="action-text">Leave feedback</span>
                        <span class="action-arrow">&rarr;</span>
                    </a>

                    <div class="helper-links">
                        <div class="helper-item">
                            <div class="helper-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                            </div>
                            <div>
                                <strong style="display: block; color: var(--dark-text);">Office Hours</strong>
                                Mon - Fri: 9:00 AM - 5:00 PM
                            </div>
                        </div>
                        <div class="helper-item">
                            <div class="helper-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            </div>
                            <div>
                                <strong style="display: block; color: var(--dark-text);">Reception</strong>
                                +1 (555) 123-4567 • ext 0
                            </div>
                        </div>
                    </div>

                </div>
                
                <!-- Right Side Visual (Abstract/Artistic) -->
                <div class="kiosk-visual" style="background-image: url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'); background-size: cover; background-position: center;">
                    <div style="position: absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(135deg, rgba(0,86,179,0.85) 0%, rgba(0,61,130,0.9) 100%);"></div>
                    <div style="position: relative; color: white; text-align: center;">
                        <div style="opacity: 0.3; margin-bottom: 1.5rem;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                        </div>
                        <h3 style="color: white; font-weight: 600;">Safety First</h3>
                        <p style="opacity: 0.8; font-size: 0.95rem; max-width: 250px; margin: 0 auto;">Please ensure you have your ID ready for verification upon entry.</p>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End .app-container -->
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>