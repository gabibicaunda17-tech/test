<?php $title = "Visitor Feedback"; include APP_ROOT . '/Views/layouts/header.php'; ?>

<div class="row align-center justify-center fade-in" style="min-height: 100vh; padding: 2rem 0;">
    <div class="container container-sm">
        <div class="card">
            <div class="text-center mb-4">
                <?php if (isset($success)): ?>
                     <h1 style="color: var(--success-color);">Thank You!</h1>
                <?php else: ?>
                    <h1 style="color: var(--primary-color);">Check-in Successful</h1>
                    <p class="text-muted">You are now checked in. Please navigate to your destination.</p>
                    <hr style="margin: 1.5rem 0; border: 0; border-top: 1px solid #eee;">
                    <p class="text-muted" style="font-size: 0.9em;">Optional: How was the check-in process?</p>
                <?php endif; ?>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger text-center"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (isset($success)): ?>
                <div class="alert alert-success text-center">
                    <p><?php echo $success; ?></p>
                </div>
                <div class="text-center mt-3">
                    <a href="<?php echo BASE_URL; ?>/" class="btn btn-primary">Return to Home</a>
                </div>
            <?php else: ?>

            <form action="<?php echo BASE_URL; ?>/visitor/feedback" method="POST">
                <input type="hidden" name="visit_id" value="<?php echo $visit_id; ?>">
                
                <div class="form-group text-center mb-4">
                    <label class="mb-3">Rate your experience</label>
                    <div class="rating-stars" style="display: flex; justify-content: center; gap: 10px; flex-direction: row-reverse;">
                        <input type="radio" name="rating" id="star5" value="5" hidden>
                        <label for="star5" title="Excellent">&#9733;</label>
                        <input type="radio" name="rating" id="star4" value="4" hidden>
                        <label for="star4" title="Good">&#9733;</label>
                        <input type="radio" name="rating" id="star3" value="3" hidden>
                        <label for="star3" title="Average">&#9733;</label>
                        <input type="radio" name="rating" id="star2" value="2" hidden>
                        <label for="star2" title="Poor">&#9733;</label>
                        <input type="radio" name="rating" id="star1" value="1" hidden>
                        <label for="star1" title="Very Poor">&#9733;</label>
                    </div>
                </div>

                <div class="form-group">
                    <label for="comment">Comments</label>
                    <textarea id="comment" name="comment" rows="4" placeholder="Share your experience..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Submit Feedback</button>
            </form>
            <?php endif; ?>
            
            <div class="text-center mt-3">
                <a href="<?php echo BASE_URL; ?>/" class="text-muted" style="font-size: 0.9rem;">&larr; Cancel</a>
            </div>
        </div>
    </div>
</div>

<script>
function setRating(val) {
    document.getElementById('rating-text').innerText = val + " Star" + (val > 1 ? "s" : "");
    // Reset all stars first
     const labels = document.querySelectorAll('label[for^=star]');
    labels.forEach(l => l.style.color = '#e4e5e9'); // Grey out all
    
    // Color up to selected
    for(let i=1; i<=val; i++) {
         document.querySelector('label[for=star'+i+']').style.color = '#ffc107';   
    }
}
</script>

<?php include APP_ROOT . '/Views/layouts/footer.php'; ?>
