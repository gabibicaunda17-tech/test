<?php
class VisitorController extends Controller {
    public function index() {
        $data = ['title' => 'Welcome to iVisit'];
        $this->view('visitor/index', $data);
    }

    public function register() {
        // Load Departments for the dropdown
        $departmentModel = $this->model('DepartmentModel');
        $departments = $departmentModel->getAllDepartments();
        $data = ['departments' => $departments];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Process form
            $visitorModel = $this->model('VisitorModel');
            
            // Basic sanitization
            $formData = [
                'full_name' => trim($_POST['full_name'] ?? ''),
                'contact_number' => trim($_POST['contact_number'] ?? ''),
                'email' => trim($_POST['email'] ?? ''),
                'organization' => trim($_POST['organization'] ?? ''),
                'person_to_visit' => trim($_POST['person_to_visit'] ?? ''),
                'department' => trim($_POST['department'] ?? ''),
                'purpose' => trim($_POST['purpose'] ?? ''),
                'purpose_details' => trim($_POST['purpose_details'] ?? ''),
            ];

            // Preserve input data
            $data = array_merge($data, $formData);

            // Validation
            if (empty($formData['full_name'])) {
                $data['error'] = 'Please enter your full name.';
                $this->view('visitor/register', $data);
                return;
            }
            // Additional validation if needed
            if (empty($formData['department'])) {
                $data['error'] = 'Please select a department.';
                $this->view('visitor/register', $data);
                return;
            }

            $visitId = $visitorModel->registerVisit($formData);
            if ($visitId) {
                // Store visit ID in session for security (prevent IDOR)
                $_SESSION['current_visit_id'] = $visitId;
                
                // Redirect to feedback
                header('Location: ' . BASE_URL . '/visitor/feedback');
                exit;
            } else {
                $data['error'] = 'Registration failed. Please try again.';
                $this->view('visitor/register', $data);
            }
        } else {
            $this->view('visitor/register', $data);
        }
    }

    public function feedback() {
        // Retrieve visit ID from session if available, fallback to GET (but prefer session)
        $visitId = $_SESSION['current_visit_id'] ?? (isset($_GET['visit_id']) ? (int)$_GET['visit_id'] : null);
        
        $data = ['title' => 'Visitor Feedback', 'visit_id' => $visitId];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $visitorModel = $this->model('VisitorModel');
            
            $visitIdPost = isset($_POST['visit_id']) ? (int)$_POST['visit_id'] : null;
            
            // Security check: Verify the posted ID matches the session (if session exists)
            if (isset($_SESSION['current_visit_id']) && $visitIdPost != $_SESSION['current_visit_id']) {
                 $data['error'] = 'Security validation failed. Please try again.';
                 $this->view('visitor/feedback', $data);
                 return;
            }

            $rating = (int)($_POST['rating'] ?? 0);
            
            if ($rating >= 1 && $rating <= 5) {
                $feedback = [
                    'visit_id' => $visitIdPost,
                    'rating' => $rating,
                    'comment' => trim($_POST['comment'] ?? ''),
                    'suggestion' => trim($_POST['suggestion'] ?? ''),
                    'contact_email' => trim($_POST['contact_email'] ?? '')
                ];
                
                if ($visitorModel->submitFeedback($feedback)) {
                    $data['success'] = 'Thank you for your feedback! Have a great day.';
                    // Clear session visit ID to prevent resubmission
                    unset($_SESSION['current_visit_id']);
                } else {
                    $data['error'] = 'Failed to submit feedback.';
                }
            } else {
                $data['error'] = 'Please select a valid rating (1-5).';
            }
        }

        $this->view('visitor/feedback', $data);
    }
}
