<?php
// app/Controllers/DepartmentController.php

class DepartmentController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }
    }

    public function index() {
        $departmentModel = $this->model('DepartmentModel');
        $departments = $departmentModel->getAllDepartments();
        
        $this->view('admin/departments/index', [
            'departments' => $departments,
            'title' => 'Departments',
            'admin_name' => $_SESSION['admin_name']
        ]);
    }

    public function add() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $departmentModel = $this->model('DepartmentModel');
            $data = [
                'name' => trim($_POST['name']),
                'description' => trim($_POST['description'])
            ];

            if ($departmentModel->addDepartment($data)) {
                $this->redirect('department/index');
            } else {
                $this->view('admin/departments/create', [
                    'error' => 'Failed to add department.',
                    'title' => 'Add Department'
                ]);
            }
        } else {
            $this->view('admin/departments/create', ['title' => 'Add Department']);
        }
    }

    public function edit($id) {
        $departmentModel = $this->model('DepartmentModel');
        $department = $departmentModel->getDepartmentById($id);

        if (!$department) {
            $this->redirect('department/index');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => trim($_POST['name']),
                'description' => trim($_POST['description'])
            ];

            if ($departmentModel->updateDepartment($id, $data)) {
                $this->redirect('department/index');
            } else {
                $this->view('admin/departments/edit', [
                    'department' => $department,
                    'error' => 'Failed to update department.',
                    'title' => 'Edit Department'
                ]);
            }
        } else {
            $this->view('admin/departments/edit', [
                'department' => $department,
                'title' => 'Edit Department'
            ]);
        }
    }

    public function delete($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $departmentModel = $this->model('DepartmentModel');
            $departmentModel->deleteDepartment($id);
        }
        $this->redirect('department/index');
    }
}