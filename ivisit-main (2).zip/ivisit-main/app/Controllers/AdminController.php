<?php
// app/Controllers/AdminController.php

class AdminController extends Controller {
    
    public function __construct() {
        // Ensure session is started in index.php
    }

    public function index() {
        // Redirect to dashboard if logged in, else login
        if (isset($_SESSION['admin_id'])) {
            $this->redirect('admin/dashboard');
        } else {
            $this->redirect('admin/login');
        }
    }

    public function login() {
        if (isset($_SESSION['admin_id'])) {
            $this->redirect('admin/dashboard');
        }

        $data = [];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            $adminModel = $this->model('AdminModel');
            $loggedInUser = $adminModel->login($email, $password);

            if ($loggedInUser) {
                // Create Session
                $_SESSION['admin_id'] = $loggedInUser['id'];
                $_SESSION['admin_name'] = $loggedInUser['name'];
                $_SESSION['admin_email'] = $loggedInUser['email'];

                $adminModel->updateLoginTimestamp($loggedInUser['id']);
                
                $this->redirect('admin/dashboard');
            } else {
                $data['error'] = 'Invalid email or password';
            }
        }

        $this->view('admin/login', $data);
    }

    public function logout() {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_email']);
        session_destroy();
        $this->redirect('admin/login');
    }

    public function dashboard() {
        if (!isset($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }

        $adminModel = $this->model('AdminModel');
        $stats = $adminModel->getDashboardStats();
        $visits = $adminModel->getTodaysVisits();
        $weeklyStats = $adminModel->getWeeklyVisitStats();
        $topDepartments = $adminModel->getTopDepartments();
        $recentFeedback = $adminModel->getRecentFeedback();

        $data = [
            'title' => 'Admin Dashboard',
            'admin_name' => $_SESSION['admin_name'],
            'stats' => $stats,
            'visits' => $visits,
            'weeklyStats' => $weeklyStats,
            'topDepartments' => $topDepartments,
            'recentFeedback' => $recentFeedback
        ];
        
        $this->view('admin/dashboard', $data);
    }

    public function mark_timeout() {
        if (!isset($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $visitId = $_POST['visit_id'] ?? 0;
            
            if ($visitId) {
                $adminModel = $this->model('AdminModel');
                $adminModel->markVisitorOut($visitId);
            }
        }

        $this->redirect('admin/dashboard');
    }

    public function visits() {
         if (!isset($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }

        $adminModel = $this->model('AdminModel');

        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $limit = 20; // Show 20 records per page
        $offset = ($page - 1) * $limit;

        $filters = [
            'date_from' => $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days')),
            'date_to' => $_GET['date_to'] ?? date('Y-m-d'),
            'status' => $_GET['status'] ?? '',
            'purpose' => $_GET['purpose'] ?? '',
            'search' => trim($_GET['search'] ?? '')
        ];

        // Call the search method in the model
        $visits = $adminModel->searchVisits($filters, $limit, $offset);
        $totalVisits = $adminModel->getVisitsCount($filters);
        $purposes = $adminModel->getDistinctPurposes();

        $totalPages = ceil($totalVisits / $limit);

        // Handle Export Request
        if (isset($_GET['export']) && $_GET['export'] == 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="visits_export_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            fputcsv($output, ['ID', 'Visitor Name', 'Email', 'Contact', 'Purpose', 'Department', 'Person to Visit', 'Check In', 'Check Out', 'Status']);
            
            // Fetch ALL matching records for export
            $allVisits = $adminModel->searchVisits($filters, 10000, 0); 
            
            foreach ($allVisits as $visit) {
                fputcsv($output, [
                    $visit['id'],
                    $visit['full_name'],
                    $visit['email'],
                    $visit['contact_number'],
                    $visit['purpose'],
                    $visit['department'],
                    $visit['person_to_visit'],
                    $visit['time_in'],
                    $visit['time_out'],
                    $visit['status']
                ]);
            }
            fclose($output);
            exit;
        }

        $data = [
            'title' => 'Visitor Logs',
            'admin_name' => $_SESSION['admin_name'],
            'visits' => $visits,
            'purposes' => $purposes,
            'filters' => $filters,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ];

        $this->view('admin/visits', $data);
    }
    
    public function feedback() {
         if (!isset($_SESSION['admin_id'])) {
            $this->redirect('admin/login');
        }

        $adminModel = $this->model('AdminModel');

        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $filters = [
            'date_from' => $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days')),
            'date_to' => $_GET['date_to'] ?? date('Y-m-d'),
            'rating' => $_GET['rating'] ?? '',
            'search' => trim($_GET['search'] ?? '')
        ];

        
        $totalFeedback = $adminModel->getFeedbackCount($filters);
        $totalPages = ceil($totalFeedback / $limit);
        
        // Pass limit and offset to model
        $feedbacks = $adminModel->getFeedback($filters, $limit, $offset);

        $data = [
            'title' => 'Visitor Feedback',
            'admin_name' => $_SESSION['admin_name'],
            'feedbacks' => $feedbacks,
            'filters' => $filters,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_items' => $totalFeedback
            ]
        ];

        $this->view('admin/feedback', $data);
    }
}
