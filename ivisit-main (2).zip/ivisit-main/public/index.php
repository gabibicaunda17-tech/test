<?php
// public/index.php

// Start Session
session_start();

// Load Config
require_once '../app/Config/config.php';

// Autoloader (Manual for now, can move to composer later)
spl_autoload_register(function ($className) {
    if (file_exists('../app/Core/' . $className . '.php')) {
        require_once '../app/Core/' . $className . '.php';
    } elseif (file_exists('../app/Controllers/' . $className . '.php')) {
        require_once '../app/Controllers/' . $className . '.php';
    } elseif (file_exists('../app/Models/' . $className . '.php')) {
        require_once '../app/Models/' . $className . '.php';
    }
});

// Init App
$app = new App;
